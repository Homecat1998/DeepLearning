Can predict the Genuine/Posed or the video number (T=true=genuine)
(If predicting G/P don't use column 2, and vice versa.)

